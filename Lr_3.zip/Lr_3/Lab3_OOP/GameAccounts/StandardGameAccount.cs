﻿namespace Lr_3.GameAccounts;

public class StandardGameAccount : GameAccount
{
    public StandardGameAccount(string name, decimal rating) : base(name, rating) { }
}