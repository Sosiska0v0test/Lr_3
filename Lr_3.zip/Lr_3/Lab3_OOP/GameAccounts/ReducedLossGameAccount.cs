﻿namespace Lr_3.GameAccounts;

public class ReducedLossGameAccount : GameAccount
{
    public ReducedLossGameAccount(string name, decimal rating) : base(name, rating) { }
}