﻿namespace Lr_3.GameAccounts;

public class WinningStreakGameAccount : GameAccount
{
    public WinningStreakGameAccount(string name, decimal rating) : base(name, rating) { }
}