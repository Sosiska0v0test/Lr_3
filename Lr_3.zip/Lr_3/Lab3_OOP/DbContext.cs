﻿using Lr_3.Entity;
using Lr_3.Entity.GameEntities;

namespace Lr_3;

public class DbContext
{
    public List<PlayerEntity> Players { get; } = new();
    public List<GameEntity> Games { get; } = new();
}